import { useEffect, useMemo, useState, type ReactNode } from "react"

type Screen = "home" | "training" | "workout" | "builder" | "analytics" | "predictor" | "records" | "coach" | "profile" | "settings" | "calculators"

type OnboardingScreen = "splash" | "welcome" | "goal" | "profile" | "devices" | "subscription" | "payment" | "register" | "login" | "complete" | "app"

type IconName = "home" | "calendar" | "chart" | "spark" | "user" | "bell" | "arrow" | "play" | "shoe" | "heart" | "clock" | "route" | "bolt" | "plus" | "settings" | "chevron" | "back" | "check" | "flame" | "target" | "moon"

const iconPaths: Record<IconName, ReactNode> = {
  home: (
    <>
      <path d="m3 10 9-7 9 7" />
      <path d="M5 9v11h14V9M9 20v-7h6v7" />
    </>
  ),
  calendar: (
    <>
      <rect x="3" y="5" width="18" height="16" rx="3" />
      <path d="M8 3v4m8-4v4M3 10h18" />
    </>
  ),
  chart: (
    <>
      <path d="M4 19V9m6 10V5m6 14v-7m5 7H2" />
    </>
  ),
  spark: (
    <>
      <path d="m12 3 1.4 4.6L18 9l-4.6 1.4L12 15l-1.4-4.6L6 9l4.6-1.4L12 3Z" />
      <path d="m19 15 .7 2.3L22 18l-2.3.7L19 21l-.7-2.3L16 18l2.3-.7L19 15Z" />
    </>
  ),
  user: (
    <>
      <circle cx="12" cy="8" r="4" />
      <path d="M4 21a8 8 0 0 1 16 0" />
    </>
  ),
  bell: (
    <>
      <path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9" />
      <path d="M10 21h4" />
    </>
  ),
  arrow: (
    <>
      <path d="M5 12h14m-5-5 5 5-5 5" />
    </>
  ),
  play: <path d="m9 6 9 6-9 6V6Z" />,
  shoe: (
    <>
      <path d="M3 15c5 1 6-2 6-7l4 4c2 2 4 3 7 3 1 0 2 1 2 2v2H4c-2 0-3-3-1-4Z" />
      <path d="M10 12h4m-2-3 4 4" />
    </>
  ),
  heart: (
    <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z" />
  ),
  clock: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 2" />
    </>
  ),
  route: (
    <>
      <circle cx="5" cy="6" r="2" />
      <circle cx="19" cy="18" r="2" />
      <path d="M7 6h3a3 3 0 0 1 0 6H8a3 3 0 0 0 0 6h9" />
    </>
  ),
  bolt: <path d="m13 2-9 12h7l-1 8 9-12h-7l1-8Z" />,
  plus: <path d="M12 5v14M5 12h14" />,
  settings: (
    <>
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H3v-4h.1a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3A1.7 1.7 0 0 0 10 3V3h4v.1a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z" />
    </>
  ),
  chevron: <path d="m9 18 6-6-6-6" />,
  back: <path d="m15 18-6-6 6-6" />,
  check: <path d="m5 12 4 4L19 6" />,
  flame: (
    <path d="M13 22c5-1 7-4.8 5.5-8.5-1-2.5-2.8-3.8-2.5-7.5-3 1.5-4.5 3.8-4 7-2-1-2.5-3-2-5-3 2-5 5.5-3.5 9 1 2.4 3.2 4.2 6.5 5Z" />
  ),
  target: (
    <>
      <circle cx="12" cy="12" r="9" />
      <circle cx="12" cy="12" r="5" />
      <circle cx="12" cy="12" r="1" />
    </>
  ),
  moon: <path d="M21 15.5A9 9 0 0 1 8.5 3 9 9 0 1 0 21 15.5Z" />,
}

function Icon({ name, size = 20 }: { name: IconName size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      {iconPaths[name]}
    </svg>
  )
}

const nav: { id: Screen label: string icon: IconName }[] = [
  { id: "home", label: "Home", icon: "home" },
  { id: "training", label: "Training", icon: "calendar" },
  { id: "analytics", label: "Analytics", icon: "chart" },
  { id: "coach", label: "Coach", icon: "spark" },
  { id: "profile", label: "Profile", icon: "user" },
]

function Card({
  children,
  className = "",
  onClick,
}: {
  children: ReactNode
  className?: string
  onClick?: () => void
}) {
  return (
    <div
      className={`card ${onClick ? "clickable" : ""} ${className}`}
      onClick={onClick}
    >
      {children}
    </div>
  )
}

function Tag({
  children,
  tone = "orange",
}: {
  children: ReactNode
  tone?: "orange" | "green" | "blue" | "neutral"
}) {
  return <span className={`tag ${tone}`}>{children}</span>
}

function Ring({
  value,
  label,
  color = "#fc5200",
  size = 70,
}: {
  value: number
  label?: string
  color?: string
  size?: number
}) {
  return (
    <div
      className="ring"
      style={{
        width: size,
        height: size,
        background: `conic-gradient(${color} ${value * 3.6}deg, var(--track) 0deg)`,
      }}
    >
      <div className="ring-inner">
        <strong>{value}</strong>
        {label && <span>{label}</span>}
      </div>
    </div>
  )
}

function Sparkline({
  color = "#fc5200",
  fill = false,
  variant = 0,
}: {
  color?: string
  fill?: boolean
  variant?: number
}) {
  const paths = [
    "M2 47 C16 43, 20 31, 33 35 S51 44, 65 27 S83 12, 96 20 S115 35, 130 14 S150 19, 168 7",
    "M2 34 C18 30, 26 42, 42 31 S65 10, 83 21 S103 41, 118 27 S142 12, 168 16",
    "M2 44 C18 39, 31 18, 48 26 S70 42, 88 30 S111 9, 128 17 S149 27, 168 11",
  ]
  return (
    <svg className="sparkline" viewBox="0 0 170 55" preserveAspectRatio="none">
      {fill && (
        <path
          d={`${paths[variant]} L168 55 L2 55 Z`}
          fill={color}
          opacity=".09"
          stroke="none"
        />
      )}
      <path
        d={paths[variant]}
        fill="none"
        stroke={color}
        strokeWidth="3"
        strokeLinecap="round"
      />
    </svg>
  )
}

function SectionTitle({
  title,
  action,
  onAction,
}: {
  title: string
  action?: string
  onAction?: () => void
}) {
  return (
    <div className="section-title">
      <h2>{title}</h2>
      {action && (
        <button onClick={onAction}>
          {action} <Icon name="chevron" size={15} />
        </button>
      )}
    </div>
  )
}

function PageHeader({
  title,
  eyebrow,
  onBack,
  action,
}: {
  title: string
  eyebrow?: string
  onBack?: () => void
  action?: ReactNode
}) {
  return (
    <header className="page-header">
      <div className="header-main">
        {onBack && (
          <button className="icon-button" onClick={onBack} aria-label="Back">
            <Icon name="back" />
          </button>
        )}
        <div>
          {eyebrow && <p className="eyebrow">{eyebrow}</p>}
          <h1>{title}</h1>
        </div>
      </div>
      {action}
    </header>
  )
}

function ProgressBar({
  value,
  color = "#fc5200",
}: {
  value: number
  color?: string
}) {
  return (
    <div className="progress">
      <span style={{ width: `${value}%`, background: color }} />
    </div>
  )
}

function PreviousHome({ go }: { go: (s: Screen) => void }) {
  return (
    <>
      <header className="home-header">
        <div>
          <p className="eyebrow">MONDAY, 12 AUGUST</p>
          <h1>
            Ready to run, <span>Alex?</span>
          </h1>
        </div>
        <button className="avatar-button">
          <span className="status-dot" />
          <Icon name="bell" />
        </button>
      </header>

      <Card className="hero-workout">
        <div className="hero-top">
          <Tag>UP NEXT · 18:00</Tag>
          <span className="weather">18° · Clear</span>
        </div>
        <div className="hero-content">
          <div>
            <p className="subtle">TODAY'S WORKOUT</p>
            <h2>Tempo Run</h2>
            <p>Build controlled speed at threshold pace.</p>
          </div>
          <div className="workout-symbol">
            <Icon name="bolt" size={30} />
          </div>
        </div>
        <div className="workout-stats">
          <div>
            <span>DISTANCE</span>
            <strong>
              6.0 <small>km</small>
            </strong>
          </div>
          <div>
            <span>TARGET PACE</span>
            <strong>
              4:15 <small>/km</small>
            </strong>
          </div>
          <div>
            <span>EST. TIME</span>
            <strong>25:30</strong>
          </div>
        </div>
        <button className="primary dark-button" onClick={() => go("workout")}>
          View workout <Icon name="arrow" />
        </button>
      </Card>

      <div className="metric-grid">
        <Card className="mileage-card">
          <div className="metric-head">
            <div className="metric-icon orange">
              <Icon name="route" />
            </div>
            <Tag tone="green">+8%</Tag>
          </div>
          <p>Weekly mileage</p>
          <h3>
            54 <small>/ 70 km</small>
          </h3>
          <ProgressBar value={77} />
          <span className="caption">16 km left this week</span>
        </Card>
        <Card>
          <div className="metric-head">
            <div className="metric-icon red">
              <Icon name="flame" />
            </div>
            <span className="tiny-label">BEST 26</span>
          </div>
          <p>Current streak</p>
          <h3>
            18 <small>days</small>
          </h3>
          <div className="week-dots">
            {["M", "T", "W", "T", "F", "S", "S"].map((d, i) => (
              <span className={i < 6 ? "done" : ""} key={i}>
                {i < 6 ? <Icon name="check" size={10} /> : d}
              </span>
            ))}
          </div>
        </Card>
      </div>

      <SectionTitle
        title="Your condition"
        action="Full analytics"
        onAction={() => go("analytics")}
      />
      <div className="score-row">
        <Card>
          <Ring value={87} />
          <div>
            <p>Performance</p>
            <h3>Excellent</h3>
            <span className="trend up">↗ 3 pts</span>
          </div>
        </Card>
        <Card>
          <Ring value={72} color="#22c55e" />
          <div>
            <p>Recovery</p>
            <h3>Good</h3>
            <span className="caption">7h 42m sleep</span>
          </div>
        </Card>
        <Card>
          <Ring value={81} color="#2563eb" />
          <div>
            <p>Readiness</p>
            <h3>Ready</h3>
            <span className="caption">Quality session</span>
          </div>
        </Card>
      </div>
      <div className="health-summary">
        <Card>
          <div className="metric-icon orange">
            <Icon name="bolt" />
          </div>
          <div>
            <p>Training load</p>
            <strong>642</strong>
            <span className="trend up">Optimal</span>
          </div>
        </Card>
        <Card>
          <div className="metric-icon blue">
            <Icon name="moon" />
          </div>
          <div>
            <p>Sleep score</p>
            <strong>84</strong>
            <span>7h 42m</span>
          </div>
        </Card>
        <Card>
          <div className="metric-icon red">
            <Icon name="heart" />
          </div>
          <div>
            <p>Heart rate</p>
            <strong>52</strong>
            <span>Resting bpm</span>
          </div>
        </Card>
      </div>

      <div className="dashboard-grid">
        <Card className="chart-card">
          <div className="chart-head">
            <div>
              <p>Weekly volume</p>
              <h3>
                54.2 <small>km</small>
              </h3>
            </div>
            <Tag tone="neutral">This week</Tag>
          </div>
          <div className="bar-chart">
            {[44, 68, 32, 83, 56, 94, 24].map((v, i) => (
              <div key={i}>
                <span
                  style={{ height: `${v}%` }}
                  className={i === 5 ? "active" : ""}
                />
                <small>{["M", "T", "W", "T", "F", "S", "S"][i]}</small>
              </div>
            ))}
          </div>
        </Card>
        <Card className="race-card" onClick={() => go("predictor")}>
          <div className="metric-icon blue">
            <Icon name="target" />
          </div>
          <p>NEXT RACE · 26 DAYS</p>
          <h3>City Park 5K</h3>
          <div className="race-goal">
            <span>GOAL</span>
            <strong>Sub 20:00</strong>
          </div>
          <ProgressBar value={74} color="#2563eb" />
          <span className="caption">74% goal probability</span>
        </Card>
      </div>
      <SectionTitle title="Recent activity" action="View all" />
      <Card className="activity-card">
        <div className="activity-icon">
          <Icon name="shoe" />
        </div>
        <div className="activity-info">
          <h3>Sunday Long Run</h3>
          <p>Yesterday · Riverside Loop</p>
          <div>
            <strong>15.2 km</strong>
            <span>1:18:42</span>
            <span>5:10/km</span>
          </div>
        </div>
        <Sparkline color="#22c55e" variant={1} />
      </Card>
    </>
  )
}

function Home({ go }: { go: (s: Screen) => void }) {
  const [adapted, setAdapted] = useState(false)
  return (
    <div className="coach-dashboard">
      <header className="home-header coaching-header">
        <div>
          <p className="eyebrow">MONDAY, 12 AUGUST · BUILD WEEK 6</p>
          <h1>
            Good morning, <span>Alex.</span>
          </h1>
          <p>Your plan adapted overnight from recovery and sleep data.</p>
        </div>
        <button className="avatar-button">
          <span className="status-dot" />
          <Icon name="bell" />
        </button>
      </header>

      <Card className="readiness-hero">
        <div className="readiness-topline">
          <Tag tone="green">READY TO TRAIN</Tag>
          <span>Updated 6:42 AM</span>
        </div>
        <div className="readiness-main">
          <div className="readiness-score">
            <Ring value={86} color="#22c55e" size={116} />
            <span>READINESS</span>
          </div>
          <div className="readiness-copy">
            <p className="eyebrow">TODAY'S DECISION</p>
            <h2>Proceed with quality.</h2>
            <p>
              Your HRV rebounded and sleep quality is strong. You're primed for
              threshold work, but keep the opening rep controlled.
            </p>
          </div>
        </div>
        <div className="readiness-signals">
          <div>
            <Icon name="moon" />
            <span>Sleep</span>
            <strong>84</strong>
            <small className="signal-up">+6</small>
          </div>
          <div>
            <Icon name="heart" />
            <span>HRV</span>
            <strong>
              68 <small>ms</small>
            </strong>
            <small className="signal-up">Baseline +4</small>
          </div>
          <div>
            <Icon name="bolt" />
            <span>Acute load</span>
            <strong>642</strong>
            <small>Optimal</small>
          </div>
        </div>
      </Card>

      <div className="coaching-section-title">
        <div>
          <span>01</span>
          <div>
            <p>YOUR PRESCRIPTION</p>
            <h2>Today's workout</h2>
          </div>
        </div>
        <Tag tone="green">AI ADAPTED</Tag>
      </div>
      <Card className="coaching-workout">
        <div className="workout-banner">
          <div>
            <Tag>THRESHOLD · 18:00</Tag>
            <h2>{adapted ? "Controlled Tempo" : "Tempo Progression"}</h2>
            <p>
              {adapted
                ? "Reduced finish intensity to protect tomorrow's recovery."
                : "Build from controlled threshold to 5K effort."}
            </p>
          </div>
          <div className="workout-symbol">
            <Icon name="bolt" size={29} />
          </div>
        </div>
        <div className="session-structure">
          <div>
            <span>WARM UP</span>
            <strong>2 km</strong>
            <small>5:20–5:40/km</small>
          </div>
          <i />
          <div className="key-block">
            <span>MAIN SET</span>
            <strong>3 × 2 km</strong>
            <small>4:12 → 4:02/km</small>
          </div>
          <i />
          <div>
            <span>COOL DOWN</span>
            <strong>1.5 km</strong>
            <small>Easy effort</small>
          </div>
        </div>
        <div className="prescription-meta">
          <span>
            <Icon name="route" /> 9.5 km
          </span>
          <span>
            <Icon name="clock" /> 48 min
          </span>
          <span>
            <Icon name="heart" /> Z4 · 164–176
          </span>
        </div>
        <div className="workout-actions">
          <button className="primary dark-button" onClick={() => go("workout")}>
            View workout <Icon name="arrow" />
          </button>
          <button
            className={adapted ? "adapt-button active" : "adapt-button"}
            onClick={() => setAdapted(!adapted)}
          >
            <Icon name="spark" />
            {adapted ? "Adapted" : "Adapt session"}
          </button>
        </div>
      </Card>

      <div className="coaching-section-title">
        <div>
          <span>02</span>
          <div>
            <p>SESSION-SPECIFIC</p>
            <h2>Fuel readiness</h2>
          </div>
        </div>
        <span className="fuel-status">
          <i /> Plan ready
        </span>
      </div>
      <Card className="fuel-card">
        <div className="fuel-intro">
          <div className="fuel-icon">
            <Icon name="bolt" size={25} />
          </div>
          <div>
            <p>FUEL SCORE · 78</p>
            <h3>Top up before your run</h3>
            <span>
              Calculated for 48 min at threshold, 18°C and your 68 kg body
              weight.
            </span>
          </div>
        </div>
        <div className="fuel-grid">
          <div className="fuel-metric carbs">
            <span className="fuel-label">
              <Icon name="bolt" /> REQUIRED CARBOHYDRATE
            </span>
            <strong>
              68 <small>g</small>
            </strong>
            <p>45–60 min before</p>
            <div className="fuel-example">
              <i>01</i>
              Banana + toast with honey
            </div>
          </div>
          <div className="fuel-metric hydration">
            <span className="fuel-label">
              <Icon name="route" /> HYDRATION
            </span>
            <strong>
              650 <small>ml</small>
            </strong>
            <p>Across the next 3 hours</p>
            <div className="fuel-example">
              <i>02</i>
              Add 400 mg sodium
            </div>
          </div>
          <div className="fuel-metric recovery-nutrition">
            <span className="fuel-label">
              <Icon name="heart" /> RECOVERY NUTRITION
            </span>
            <strong>
              25 <small>g protein</small>
            </strong>
            <p>Within 45 min after</p>
            <div className="fuel-example">
              <i>03</i>
              Add 75 g carbohydrate
            </div>
          </div>
        </div>
        <button className="fuel-detail-button">
          View full nutrition plan <Icon name="arrow" size={16} />
        </button>
      </Card>

      <div className="coaching-split">
        <section>
          <div className="coaching-section-title compact">
            <div>
              <span>03</span>
              <div>
                <p>BODY STATUS</p>
                <h2>Recovery</h2>
              </div>
            </div>
          </div>
          <Card className="recovery-panel">
            <div className="recovery-score-row">
              <Ring value={74} color="#2563eb" size={78} />
              <div>
                <Tag tone="blue">GOOD</Tag>
                <h3>Recovery is trending up</h3>
                <p>+9% since yesterday</p>
              </div>
            </div>
            {[
              ["Sleep duration", "7h 42m", 88, "#2563eb"],
              ["Resting HR", "52 bpm", 81, "#22c55e"],
              ["Muscle strain", "Moderate", 63, "#f59e0b"],
            ].map(([label, value, score, color]) => (
              <div className="recovery-signal" key={String(label)}>
                <div>
                  <span>{label}</span>
                  <strong>{value}</strong>
                </div>
                <ProgressBar value={Number(score)} color={String(color)} />
              </div>
            ))}
          </Card>
        </section>

        <section>
          <div className="coaching-section-title compact">
            <div>
              <span>04</span>
              <div>
                <p>RACE TRAJECTORY</p>
                <h2>Goal progress</h2>
              </div>
            </div>
          </div>
          <Card className="goal-progress-card" onClick={() => go("predictor")}>
            <div className="goal-head">
              <div>
                <Tag>5K · 26 DAYS</Tag>
                <h3>Sub 20:00</h3>
                <p>City Park 5K</p>
              </div>
              <Ring value={74} label="probability" color="#fc5200" size={76} />
            </div>
            <div className="projected-time">
              <span>PROJECTED TODAY</span>
              <strong>20:18</strong>
              <small className="signal-up">↗ 22 sec this month</small>
            </div>
            <div className="goal-timeline">
              {[
                ["Now", "20:18", true],
                ["Sharpen", "20:06", true],
                ["Race", "19:52", false],
              ].map(([label, time, done]) => (
                <span className={done ? "done" : ""} key={String(label)}>
                  <i />
                  <small>{label}</small>
                  <strong>{time}</strong>
                </span>
              ))}
            </div>
          </Card>
        </section>
      </div>

      <div className="coaching-section-title">
        <div>
          <span>05</span>
          <div>
            <p>PERSONAL COACHING</p>
            <h2>AI Coach insight</h2>
          </div>
        </div>
        <span className="coach-live">
          <i /> LIVE
        </span>
      </div>
      <Card className="dashboard-coach-card" onClick={() => go("coach")}>
        <div className="coach-intelligence">
          <Icon name="spark" size={26} />
        </div>
        <div className="coach-message">
          <Tag tone="blue">TODAY'S PRIORITY</Tag>
          <h3>Don't chase pace in the first repetition.</h3>
          <p>
            Your best threshold sessions happen when rep one is 3–5 seconds
            slower than target. Let heart rate settle, then progress.
          </p>
          <div className="coach-evidence">
            <span>
              <strong>4/5</strong> similar sessions completed
            </span>
            <span>
              <strong>−3 bpm</strong> aerobic drift
            </span>
          </div>
        </div>
        <Icon name="chevron" />
      </Card>
    </div>
  )
}

const planDays = [
  {
    day: "MON",
    date: "12",
    title: "Recovery Run",
    meta: "5 km · 5:35/km",
    state: "done",
    color: "green",
  },
  {
    day: "TUE",
    date: "13",
    title: "Tempo Run",
    meta: "6 km · 4:15/km",
    state: "today",
    color: "orange",
  },
  {
    day: "WED",
    date: "14",
    title: "Rest & Mobility",
    meta: "20 min mobility",
    state: "",
    color: "blue",
  },
  {
    day: "THU",
    date: "15",
    title: "Intervals",
    meta: "8 × 400m · 3:50/km",
    state: "",
    color: "orange",
  },
  {
    day: "FRI",
    date: "16",
    title: "Easy Run",
    meta: "7 km · 5:20/km",
    state: "",
    color: "green",
  },
  {
    day: "SAT",
    date: "17",
    title: "Rest Day",
    meta: "Full recovery",
    state: "",
    color: "blue",
  },
  {
    day: "SUN",
    date: "18",
    title: "Long Run",
    meta: "16 km · 5:05/km",
    state: "",
    color: "orange",
  },
]

function Training({ go }: { go: (s: Screen) => void }) {
  const [view, setView] = useState<"week" | "month">("week")
  return (
    <>
      <PageHeader
        eyebrow="YOUR PLAN"
        title="5K Sub 20"
        action={
          <button className="icon-button" onClick={() => go("builder")}>
            <Icon name="plus" />
          </button>
        }
      />
      <Card className="plan-overview">
        <div>
          <Tag tone="blue">WEEK 6 OF 12</Tag>
          <h2>Build & sharpen</h2>
          <p>Threshold development with controlled speed.</p>
        </div>
        <Ring value={64} label="%" />
        <div className="plan-kpis">
          <span>
            <small>COMPLETED</small>
            <strong>23 / 36</strong>
          </span>
          <span>
            <small>THIS WEEK</small>
            <strong>54 / 70 km</strong>
          </span>
          <span>
            <small>CONSISTENCY</small>
            <strong>92%</strong>
          </span>
        </div>
      </Card>
      <div className="segmented">
        <button
          className={view === "week" ? "active" : ""}
          onClick={() => setView("week")}
        >
          Week
        </button>
        <button
          className={view === "month" ? "active" : ""}
          onClick={() => setView("month")}
        >
          Month
        </button>
      </div>
      {view === "week" ? (
        <>
          <div className="week-selector">
            <button>
              <Icon name="back" size={16} />
            </button>
            <strong>12–18 August</strong>
            <button>
              <Icon name="chevron" size={16} />
            </button>
          </div>
          <div className="schedule">
            {planDays.map((item) => (
              <Card
                key={item.day}
                className={`schedule-item ${item.state}`}
                onClick={
                  item.state === "today" ? () => go("workout") : undefined
                }
              >
                <div className="date">
                  <small>{item.day}</small>
                  <strong>{item.date}</strong>
                </div>
                <div className={`type-line ${item.color}`} />
                <div className="schedule-copy">
                  <h3>{item.title}</h3>
                  <p>{item.meta}</p>
                </div>
                {item.state === "done" ? (
                  <span className="done-check">
                    <Icon name="check" size={15} />
                  </span>
                ) : item.state === "today" ? (
                  <Tag>Today</Tag>
                ) : (
                  <Icon name="chevron" size={18} />
                )}
              </Card>
            ))}
          </div>
        </>
      ) : (
        <MonthCalendar />
      )}
      <SectionTitle title="Explore plans" action="See all" />
      <div className="plan-list">
        {[
          "Couch to 5K",
          "5K Beginner",
          "10K Strong",
          "Half Marathon",
          "Marathon",
        ].map((p, i) => (
          <Card key={p}>
            <div className={`metric-icon ${i % 2 ? "blue" : "orange"}`}>
              <Icon name={i < 2 ? "shoe" : "target"} />
            </div>
            <div>
              <h3>{p}</h3>
              <p>
                {[8, 10, 12, 16, 20][i]} weeks ·{" "}
                {i < 2 ? "Beginner" : "Intermediate"}
              </p>
            </div>
            <Icon name="chevron" />
          </Card>
        ))}
      </div>
    </>
  )
}

function MonthCalendar() {
  return (
    <Card className="calendar-card">
      <div className="calendar-head">
        <button>
          <Icon name="back" size={16} />
        </button>
        <h3>August 2025</h3>
        <button>
          <Icon name="chevron" size={16} />
        </button>
      </div>
      <div className="calendar-grid">
        {["M", "T", "W", "T", "F", "S", "S"].map((d, i) => (
          <small key={i}>{d}</small>
        ))}
        {Array.from({ length: 35 }, (_, i) => {
          const n = i - 3
          return (
            <span
              className={
                n === 13
                  ? "selected"
                  : n > 0 &&
                      [2, 5, 7, 9, 12, 15, 18, 21, 23, 26, 28].includes(n)
                    ? "trained"
                    : ""
              }
              key={i}
            >
              {n > 0 && n < 32 ? n : ""}
            </span>
          )
        })}
      </div>
    </Card>
  )
}

function Workout({ go }: { go: (s: Screen) => void }) {
  const [started, setStarted] = useState(false)
  return (
    <>
      <PageHeader
        title="Workout"
        onBack={() => go("training")}
        action={
          <button className="icon-button">
            <Icon name="settings" />
          </button>
        }
      />
      <Card className="workout-detail-hero">
        <Tag>THRESHOLD</Tag>
        <div className="large-symbol">
          <Icon name="bolt" size={34} />
        </div>
        <h1>Tempo Run</h1>
        <p>
          Stay smooth and controlled. You should be able to speak in short
          phrases.
        </p>
        <div className="big-distance">
          6.0 <span>km</span>
        </div>
        <p className="pace-target">@ 4:15 /km</p>
        <div className="detail-stats">
          <span>
            <Icon name="clock" />
            <small>ESTIMATED</small>
            <strong>25:30</strong>
          </span>
          <span>
            <Icon name="heart" />
            <small>HEART RATE</small>
            <strong>164–176</strong>
          </span>
          <span>
            <Icon name="bolt" />
            <small>LOAD</small>
            <strong>82</strong>
          </span>
        </div>
      </Card>
      <SectionTitle title="Workout structure" />
      <div className="workout-blocks">
        <Card>
          <div className="block-number blue">01</div>
          <div>
            <Tag tone="blue">WARM UP</Tag>
            <h3>Easy running</h3>
            <p>1.5 km · 5:30–5:50/km</p>
          </div>
          <span>~ 8 min</span>
        </Card>
        <Card>
          <div className="block-number orange">02</div>
          <div>
            <Tag>MAIN SET</Tag>
            <h3>Tempo effort</h3>
            <p>6.0 km · 4:15/km · Zone 4</p>
          </div>
          <span>25:30</span>
        </Card>
        <Card>
          <div className="block-number green">03</div>
          <div>
            <Tag tone="green">COOL DOWN</Tag>
            <h3>Easy jog</h3>
            <p>1.5 km · Conversational</p>
          </div>
          <span>~ 9 min</span>
        </Card>
      </div>
      <Card className="coach-note">
        <div className="coach-avatar">
          <Icon name="spark" />
        </div>
        <div>
          <Tag tone="neutral">COACH TIP</Tag>
          <p>
            Start the first kilometer conservatively. Find your rhythm, then
            lock into 4:15 pace.
          </p>
        </div>
      </Card>
      <button
        className={`primary sticky-cta ${started ? "started" : ""}`}
        onClick={() => setStarted(!started)}
      >
        <Icon name={started ? "check" : "play"} />
        {started ? "Workout started" : "Start workout"}
      </button>
    </>
  )
}

function Builder({ go }: { go: (s: Screen) => void }) {
  const [repeats, setRepeats] = useState(10)
  const [preset, setPreset] = useState(0)
  const presets = [
    ["400m", "90 sec", "3:45/km"],
    ["800m", "2 min", "3:51/km"],
    ["1000m", "2:30", "3:55/km"],
  ]
  const load = repeats * 7 + 14
  return (
    <>
      <PageHeader
        eyebrow="CUSTOM WORKOUT"
        title="Interval builder"
        onBack={() => go("training")}
        action={<button className="text-button">Save</button>}
      />
      <div className="preset-row">
        {["10 × 400m", "6 × 800m", "5 × 1000m"].map((p, i) => (
          <button
            className={preset === i ? "active" : ""}
            key={p}
            onClick={() => {
              setPreset(i)
              setRepeats([10, 6, 5][i])
            }}
          >
            {p}
          </button>
        ))}
      </div>
      <Card className="builder-form">
        <div className="form-row">
          <div>
            <label>REPEAT COUNT</label>
            <h3>{repeats} repeats</h3>
          </div>
          <div className="stepper">
            <button onClick={() => setRepeats(Math.max(1, repeats - 1))}>
              −
            </button>
            <strong>{repeats}</strong>
            <button onClick={() => setRepeats(repeats + 1)}>+</button>
          </div>
        </div>
        <div className="input-grid">
          <label>
            WORK INTERVAL
            <div>
              <strong>{presets[preset][0]}</strong>
              <span>Distance</span>
            </div>
          </label>
          <label>
            RECOVERY
            <div>
              <strong>{presets[preset][1]}</strong>
              <span>Jog</span>
            </div>
          </label>
          <label>
            TARGET PACE
            <div>
              <strong>{presets[preset][2]}</strong>
              <span>Per km</span>
            </div>
          </label>
          <label>
            HR ZONE
            <div>
              <strong>Zone 5</strong>
              <span>176–188</span>
            </div>
          </label>
        </div>
      </Card>
      <SectionTitle title="Workout timeline" />
      <Card className="timeline-card">
        <div className="timeline-legend">
          <span>
            <i className="warm" />
            Warm up
          </span>
          <span>
            <i className="work" />
            Work
          </span>
          <span>
            <i className="rest" />
            Recovery
          </span>
        </div>
        <div className="interval-chart">
          <span className="warm" style={{ width: "14%" }} />
          {Array.from({ length: Math.min(repeats, 10) }, (_, i) => (
            <span
              className={i % 2 ? "rest" : "work"}
              style={{ flex: i % 2 ? 1 : 1.5 }}
              key={i}
            />
          ))}
          <span className="warm" style={{ width: "14%" }} />
        </div>
        <div className="timeline-labels">
          <span>10m warm up</span>
          <strong>{repeats} repeats</strong>
          <span>10m cool down</span>
        </div>
      </Card>
      <div className="metric-grid builder-totals">
        <Card>
          <p>TOTAL DURATION</p>
          <h3>
            {42 + repeats}
            <small> min</small>
          </h3>
        </Card>
        <Card>
          <p>TRAINING LOAD</p>
          <h3>
            {load}
            <small> · High</small>
          </h3>
        </Card>
      </div>
      <button className="primary">
        <Icon name="check" />
        Add to training plan
      </button>
    </>
  )
}

function Analytics({ go }: { go: (s: Screen) => void }) {
  const [range, setRange] = useState("12W")
  return (
    <>
      <PageHeader
        eyebrow="FITNESS TRENDS"
        title="Performance"
        action={
          <div className="range-select">
            {["4W", "12W", "1Y"].map((r) => (
              <button
                className={range === r ? "active" : ""}
                onClick={() => setRange(r)}
                key={r}
              >
                {r}
              </button>
            ))}
          </div>
        }
      />
      <div className="analytics-kpis">
        <Card>
          <div className="metric-head">
            <div className="metric-icon blue">
              <Icon name="bolt" />
            </div>
            <span className="trend up">↗ 1.4</span>
          </div>
          <p>VO₂ MAX</p>
          <h3>56.8</h3>
          <Sparkline color="#2563eb" fill />
        </Card>
        <Card>
          <div className="metric-head">
            <div className="metric-icon orange">
              <Icon name="route" />
            </div>
            <span className="trend up">↗ 4.2%</span>
          </div>
          <p>PACE TREND</p>
          <h3>
            4:38 <small>/km</small>
          </h3>
          <Sparkline fill variant={2} />
        </Card>
        <Card>
          <div className="metric-head">
            <div className="metric-icon green">
              <Icon name="heart" />
            </div>
            <span className="trend down">↓ 3 bpm</span>
          </div>
          <p>AVG. HEART RATE</p>
          <h3>
            148 <small>bpm</small>
          </h3>
          <Sparkline color="#22c55e" fill variant={1} />
        </Card>
      </div>
      <Card className="fitness-chart">
        <div className="chart-head">
          <div>
            <p>Fitness & fatigue</p>
            <h3>Training load balance</h3>
          </div>
          <Tag tone="green">Optimal</Tag>
        </div>
        <svg viewBox="0 0 360 150" preserveAspectRatio="none">
          <defs>
            <linearGradient id="area" x1="0" y1="0" x2="0" y2="1">
              <stop stopColor="#fc5200" stopOpacity=".25" />
              <stop offset="1" stopColor="#fc5200" stopOpacity="0" />
            </linearGradient>
          </defs>
          <path
            d="M0 115 C25 108 38 78 63 87 S100 113 125 73 S165 54 190 67 S224 96 250 52 S292 37 315 48 S342 31 360 22 L360 150 L0 150Z"
            fill="url(#area)"
          />
          <path
            d="M0 115 C25 108 38 78 63 87 S100 113 125 73 S165 54 190 67 S224 96 250 52 S292 37 315 48 S342 31 360 22"
            fill="none"
            stroke="#fc5200"
            strokeWidth="3"
          />
          <path
            d="M0 90 C40 95 50 66 85 75 S130 108 165 90 S220 58 250 69 S300 76 360 51"
            fill="none"
            stroke="#2563eb"
            strokeWidth="2"
            strokeDasharray="5 5"
          />
        </svg>
        <div className="chart-axis">
          <span>May 20</span>
          <span>Jun 17</span>
          <span>Jul 15</span>
          <span>Aug 12</span>
        </div>
      </Card>
      <div className="metric-grid">
        <Card>
          <p>WEEKLY DISTANCE</p>
          <h3>
            54.2 <small>km</small>
          </h3>
          <ProgressBar value={77} />
          <span className="caption">Target 70 km</span>
        </Card>
        <Card>
          <p>MONTHLY DISTANCE</p>
          <h3>
            186 <small>km</small>
          </h3>
          <ProgressBar value={68} color="#2563eb" />
          <span className="caption">+12% vs last month</span>
        </Card>
      </div>
      <SectionTitle title="Recovery status" />
      <div className="recovery-grid">
        {[
          ["Readiness", "81", "High", "#2563eb"],
          ["Recovery", "72%", "Good", "#22c55e"],
          ["Fatigue", "38", "Low", "#f59e0b"],
        ].map(([a, b, c, d]) => (
          <Card key={a}>
            <Ring value={Number(b.replace("%", ""))} color={d} size={62} />
            <div>
              <p>{a}</p>
              <h3>{b}</h3>
              <span className="caption">{c}</span>
            </div>
          </Card>
        ))}
      </div>
      <SectionTitle title="Tools & insights" />
      <div className="tool-grid">
        <Card onClick={() => go("predictor")}>
          <Icon name="target" />
          <h3>Race predictor</h3>
          <p>Project your next PR</p>
          <Icon name="chevron" />
        </Card>
        <Card onClick={() => go("records")}>
          <Icon name="bolt" />
          <h3>Personal records</h3>
          <p>Track every milestone</p>
          <Icon name="chevron" />
        </Card>
        <Card onClick={() => go("calculators")}>
          <Icon name="chart" />
          <h3>Running tools</h3>
          <p>Pace, VDOT & zones</p>
          <Icon name="chevron" />
        </Card>
      </div>
    </>
  )
}

function Predictor({ go }: { go: (s: Screen) => void }) {
  const [minutes, setMinutes] = useState(22)
  const factor = minutes / 22
  const predictions = [
    ["5K", 21.17 * factor, "21:10"],
    ["10K", 45 * factor, "45:00"],
    ["Half Marathon", 99 * factor, "1:39:00"],
    ["Marathon", 212 * factor, "3:32:00"],
  ]
  const fmt = (m: number) =>
    m >= 60
      ? `${Math.floor(m / 60)}:${String(Math.round(m % 60)).padStart(2, "0")}:00`
      : `${Math.floor(m)}:${String(Math.round((m % 1) * 60)).padStart(2, "0")}`
  return (
    <>
      <PageHeader
        eyebrow="PERFORMANCE MODEL"
        title="Race predictor"
        onBack={() => go("analytics")}
      />
      <Card className="race-input">
        <label>RECENT RACE RESULT</label>
        <div className="race-input-row">
          <button>
            5K <Icon name="chevron" size={16} />
          </button>
          <div>
            <input
              aria-label="Race time minutes"
              type="number"
              value={minutes}
              onChange={(e) => setMinutes(Number(e.target.value))}
            />
            <span>:00</span>
          </div>
        </div>
        <p>City Park 5K · 28 July 2025</p>
      </Card>
      <Card className="confidence-card">
        <div>
          <Tag tone="green">MODEL UPDATED</Tag>
          <h2>Your fitness is trending up</h2>
          <p>Based on 12 weeks of training and your recent 5K.</p>
        </div>
        <Ring value={89} label="confidence" color="#22c55e" size={86} />
      </Card>
      <SectionTitle title="Predicted race times" />
      <div className="prediction-list">
        {predictions.map(([label, value, fallback], i) => (
          <Card key={String(label)}>
            <div className="place">{i + 1}</div>
            <div>
              <p>{label}</p>
              <h3>{minutes === 22 ? fallback : fmt(Number(value))}</h3>
            </div>
            <span className={i === 0 ? "trend up" : "caption"}>
              {i === 0
                ? "↗ 0:50 faster"
                : ["Strong", "On track", "Building"][i]}
            </span>
          </Card>
        ))}
      </div>
      <Card className="progression-card">
        <div className="chart-head">
          <div>
            <p>Sub 20 progression</p>
            <h3>74% goal probability</h3>
          </div>
          <Tag tone="blue">26 days</Tag>
        </div>
        <div className="progression">
          <span className="complete">
            <i />
            22:00
          </span>
          <span className="complete">
            <i />
            21:00
          </span>
          <span className="complete">
            <i />
            20:30
          </span>
          <span>
            <i />
            20:00
          </span>
          <span>
            <i />
            Sub20
          </span>
        </div>
        <ProgressBar value={74} color="#2563eb" />
      </Card>
    </>
  )
}

function Records({ go }: { go: (s: Screen) => void }) {
  const records = [
    ["1K", "3:32", "Track session", "02 Aug 2025", "−0:06"],
    ["5K", "21:10", "City Park 5K", "28 Jul 2025", "−0:50"],
    ["10K", "44:52", "Riverside 10K", "16 Jun 2025", "−1:12"],
    ["Half", "1:39:18", "Spring Half", "12 Apr 2025", "−3:41"],
    ["Marathon", "3:38:42", "London Marathon", "21 Apr 2024", "First"],
  ]
  return (
    <>
      <PageHeader
        eyebrow="ALL-TIME BESTS"
        title="Personal records"
        onBack={() => go("analytics")}
      />
      <Card className="record-hero">
        <div>
          <Tag>NEW PB</Tag>
          <p>Latest achievement</p>
          <h2>
            21:10 <small>5K</small>
          </h2>
          <span>50 seconds faster · 28 July</span>
        </div>
        <div className="trophy">
          <Icon name="bolt" size={36} />
        </div>
      </Card>
      <div className="record-list">
        {records.map((r, i) => (
          <Card key={r[0]}>
            <div className="record-distance">{r[0]}</div>
            <div>
              <h3>{r[1]}</h3>
              <p>
                {r[2]} · {r[3]}
              </p>
            </div>
            <Tag tone={i < 4 ? "green" : "neutral"}>{r[4]}</Tag>
          </Card>
        ))}
      </div>
      <SectionTitle title="5K progression" />
      <Card className="progress-chart">
        <div className="chart-head">
          <div>
            <p>12 month improvement</p>
            <h3>−2:38</h3>
          </div>
          <Tag tone="green">11% faster</Tag>
        </div>
        <svg viewBox="0 0 360 130" preserveAspectRatio="none">
          <path
            d="M5 22 C45 29 66 31 94 48 S142 45 176 68 S226 70 256 92 S312 99 355 116"
            fill="none"
            stroke="#fc5200"
            strokeWidth="4"
            strokeLinecap="round"
          />
          {[
            [5, 22],
            [94, 48],
            [176, 68],
            [256, 92],
            [355, 116],
          ].map(([x, y], i) => (
            <circle
              key={i}
              cx={x}
              cy={y}
              r="5"
              fill="white"
              stroke="#fc5200"
              strokeWidth="3"
            />
          ))}
        </svg>
        <div className="chart-axis">
          <span>23:48</span>
          <span>23:10</span>
          <span>22:32</span>
          <span>21:58</span>
          <span>21:10</span>
        </div>
      </Card>
    </>
  )
}

function Coach() {
  const [text, setText] = useState("")
  const [messages, setMessages] = useState<string[]>([])
  const send = () => {
    if (text.trim()) {
      setMessages([...messages, text])
      setText("")
    }
  }
  return (
    <>
      <PageHeader
        eyebrow="PERSONALIZED DAILY"
        title="AI Coach"
        action={
          <div className="online-pill">
            <i /> Online
          </div>
        }
      />
      <Card className="coach-brief">
        <div className="coach-orb">
          <Icon name="spark" size={30} />
        </div>
        <Tag>MONDAY BRIEFING</Tag>
        <h2>You're ready for quality work.</h2>
        <p>
          Your recovery has improved 8% since yesterday. Today's tempo session
          is well timed—keep the opening kilometer controlled.
        </p>
        <div className="coach-stats">
          <span>
            <strong>81</strong>Readiness
          </span>
          <span>
            <strong>72%</strong>Recovery
          </span>
          <span>
            <strong>7:42</strong>Sleep
          </span>
        </div>
      </Card>
      <SectionTitle title="Coach recommendations" />
      <div className="insight-grid">
        <Card>
          <div className="metric-icon orange">
            <Icon name="shoe" />
          </div>
          <Tag>WORKOUT</Tag>
          <h3>Keep today's tempo</h3>
          <p>Conditions and recovery are ideal. Target 4:15–4:18/km.</p>
          <button>
            View workout <Icon name="arrow" size={16} />
          </button>
        </Card>
        <Card>
          <div className="metric-icon green">
            <Icon name="heart" />
          </div>
          <Tag tone="green">RECOVERY</Tag>
          <h3>Prioritize hydration</h3>
          <p>Your resting heart rate is 3 bpm above baseline.</p>
          <button>
            Learn why <Icon name="arrow" size={16} />
          </button>
        </Card>
        <Card>
          <div className="metric-icon blue">
            <Icon name="target" />
          </div>
          <Tag tone="blue">RACE UPDATE</Tag>
          <h3>Sub 20 is within reach</h3>
          <p>Goal probability moved from 69% to 74% this week.</p>
          <button>
            See prediction <Icon name="arrow" size={16} />
          </button>
        </Card>
      </div>
      <Card className="weekly-insight">
        <div className="insight-head">
          <Icon name="spark" />
          <div>
            <Tag tone="neutral">WEEKLY INSIGHT</Tag>
            <h3>Your easy runs are getting easier</h3>
          </div>
        </div>
        <p>
          At the same 5:20/km pace, your average heart rate dropped from 151 to
          146 bpm. That's a strong aerobic adaptation.
        </p>
        <Sparkline color="#2563eb" fill variant={1} />
      </Card>
      {messages.map((m, i) => (
        <div className="chat-bubble" key={i}>
          {m}
        </div>
      ))}
      <div className="coach-input">
        <input
          placeholder="Ask your coach anything…"
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && send()}
        />
        <button onClick={send}>
          <Icon name="arrow" />
        </button>
      </div>
    </>
  )
}

function Profile({
  go,
  dark,
  toggleDark,
}: {
  go: (s: Screen) => void
  dark: boolean
  toggleDark: () => void
}) {
  return (
    <>
      <PageHeader
        title="Profile"
        action={
          <button className="icon-button" onClick={() => go("settings")}>
            <Icon name="settings" />
          </button>
        }
      />
      <Card className="profile-card">
        <div className="profile-avatar">
          AR
          <span />
        </div>
        <div>
          <h2>Alex Rivera</h2>
          <p>Intermediate runner · London</p>
          <Tag>SUB 20 5K</Tag>
        </div>
        <button className="edit-button">Edit</button>
      </Card>
      <div className="profile-stats">
        {[
          ["68", "kg", "Weight"],
          ["178", "cm", "Height"],
          ["29", "", "Age"],
          ["54", "km", "Weekly"],
        ].map((x) => (
          <Card key={x[2]}>
            <strong>
              {x[0]} <small>{x[1]}</small>
            </strong>
            <span>{x[2]}</span>
          </Card>
        ))}
      </div>
      <SectionTitle title="Running zones" action="Edit" />
      <Card className="zones-card">
        {[
          ["Easy", "5:20–5:55", "#22c55e"],
          ["Steady", "4:45–5:19", "#84cc16"],
          ["Tempo", "4:10–4:44", "#f59e0b"],
          ["Threshold", "3:55–4:09", "#fc5200"],
          ["Interval", "3:30–3:54", "#ef4444"],
        ].map((z, i) => (
          <div key={z[0]}>
            <span className="zone-number" style={{ background: z[2] }}>
              {i + 1}
            </span>
            <strong>{z[0]}</strong>
            <p>{z[1]} /km</p>
          </div>
        ))}
      </Card>
      <SectionTitle title="Shoe rotation" action="Manage" />
      <div className="shoe-list">
        {[
          ["Daily Trainer", "Nike Pegasus 41", "482 km", 69],
          ["Tempo Shoe", "Saucony Endorphin Speed", "218 km", 36],
          ["Racing Shoe", "Nike Vaporfly 3", "86 km", 18],
        ].map((s, i) => (
          <Card key={s[0]}>
            <div className={`shoe-art shoe-${i}`}>
              <Icon name="shoe" size={28} />
            </div>
            <div>
              <Tag tone="neutral">{s[0]}</Tag>
              <h3>{s[1]}</h3>
              <p>{s[2]} logged</p>
              <ProgressBar
                value={Number(s[3])}
                color={i === 0 ? "#fc5200" : i === 1 ? "#2563eb" : "#22c55e"}
              />
            </div>
            <Icon name="chevron" />
          </Card>
        ))}
      </div>
      <button className="settings-row" onClick={toggleDark}>
        <span>
          <Icon name="moon" />
          Dark mode
        </span>
        <i className={`toggle ${dark ? "on" : ""}`} />
      </button>
    </>
  )
}

function Settings({
  go,
  dark,
  toggleDark,
}: {
  go: (s: Screen) => void
  dark: boolean
  toggleDark: () => void
}) {
  const [connected, setConnected] = useState(["Strava", "Apple Watch"])
  const toggle = (name: string) =>
    setConnected((x) =>
      x.includes(name) ? x.filter((i) => i !== name) : [...x, name],
    )
  return (
    <>
      <PageHeader title="Settings" onBack={() => go("profile")} />
      <SectionTitle title="Connected apps" />
      <div className="integration-list">
        {[
          ["Garmin", "#167dcc"],
          ["Strava", "#fc5200"],
          ["Apple Watch", "#111827"],
          ["COROS", "#d40000"],
          ["Polar", "#e10026"],
        ].map(([n, c]) => (
          <Card key={n}>
            <div className="brand-logo" style={{ background: c }}>
              {n.slice(0, 1)}
            </div>
            <div>
              <h3>{n}</h3>
              <p>
                {connected.includes(n)
                  ? "Connected · Syncing"
                  : "Not connected"}
              </p>
            </div>
            <button
              className={connected.includes(n) ? "connected" : ""}
              onClick={() => toggle(n)}
            >
              {connected.includes(n) ? "Connected" : "Connect"}
            </button>
          </Card>
        ))}
      </div>
      <SectionTitle title="Preferences" />
      <Card className="settings-list">
        <button onClick={toggleDark}>
          <span>
            <Icon name="moon" />
            Theme
          </span>
          <p>
            {dark ? "Dark" : "Light"} <Icon name="chevron" />
          </p>
        </button>
        <button>
          <span>
            <Icon name="bell" />
            Notifications
          </span>
          <p>
            On <Icon name="chevron" />
          </p>
        </button>
        <button>
          <span>
            <Icon name="route" />
            Units
          </span>
          <p>
            Kilometers <Icon name="chevron" />
          </p>
        </button>
        <button>
          <span>
            <Icon name="spark" />
            Language
          </span>
          <p>
            English <Icon name="chevron" />
          </p>
        </button>
        <button>
          <span>
            <Icon name="settings" />
            Training preferences
          </span>
          <p>
            <Icon name="chevron" />
          </p>
        </button>
      </Card>
    </>
  )
}

function Calculators({ go }: { go: (s: Screen) => void }) {
  const [tool, setTool] = useState("Pace")
  const [distance, setDistance] = useState(10)
  const [time, setTime] = useState(45)
  const pace = time / distance
  const paceMin = Math.floor(pace),
    paceSec = Math.round((pace - paceMin) * 60)
  return (
    <>
      <PageHeader
        eyebrow="RUN SMARTER"
        title="Running tools"
        onBack={() => go("analytics")}
      />
      <div className="tool-tabs">
        {["Pace", "VDOT", "Race time", "Running zones", "HR zones"].map((t) => (
          <button
            className={tool === t ? "active" : ""}
            onClick={() => setTool(t)}
            key={t}
          >
            {t}
          </button>
        ))}
      </div>
      <Card className="calculator-card">
        <div className="calculator-icon">
          <Icon
            name={
              tool.includes("zone")
                ? "heart"
                : tool === "VDOT"
                  ? "bolt"
                  : "clock"
            }
            size={30}
          />
        </div>
        <p className="eyebrow">{tool.toUpperCase()} CALCULATOR</p>
        <h2>
          {tool === "Pace"
            ? "Find your target pace"
            : tool === "VDOT"
              ? "Measure running fitness"
              : tool === "Race time"
                ? "Predict your finish"
                : tool === "Running zones"
                  ? "Personal pace zones"
                  : "Heart rate zones"}
        </h2>
        <div className="calc-inputs">
          <label>
            DISTANCE (KM)
            <input
              type="number"
              value={distance}
              onChange={(e) => setDistance(Math.max(1, Number(e.target.value)))}
            />
          </label>
          <label>
            TIME (MINUTES)
            <input
              type="number"
              value={time}
              onChange={(e) => setTime(Math.max(1, Number(e.target.value)))}
            />
          </label>
        </div>
        <button className="primary">Calculate result</button>
      </Card>
      <Card className="calc-result">
        <Tag tone="green">YOUR RESULT</Tag>
        {tool === "Pace" && (
          <>
            <p>Average pace</p>
            <h2>
              {paceMin}:{String(paceSec).padStart(2, "0")} <small>/km</small>
            </h2>
          </>
        )}
        {tool === "VDOT" && (
          <>
            <p>Estimated VDOT</p>
            <h2>
              {Math.round(62 - (time - 40) * 0.8)} <small>Excellent</small>
            </h2>
          </>
        )}
        {tool === "Race time" && (
          <>
            <p>Half marathon estimate</p>
            <h2>
              {Math.floor((time * 2.22) / 60)}:
              {String(Math.round((time * 2.22) % 60)).padStart(2, "0")}{" "}
              <small>finish</small>
            </h2>
          </>
        )}
        {(tool === "Running zones" || tool === "HR zones") && (
          <div className="result-zones">
            {[1, 2, 3, 4, 5].map((z) => (
              <span key={z}>
                <i
                  style={{
                    background: [
                      "#22c55e",
                      "#84cc16",
                      "#f59e0b",
                      "#fc5200",
                      "#ef4444",
                    ][z - 1],
                  }}
                />
                Zone {z}
                <strong>
                  {tool === "HR zones"
                    ? `${120 + z * 10}–${129 + z * 10} bpm`
                    : `${paceMin + 1 - Math.floor(z / 2)}:${String((paceSec + z * 7) % 60).padStart(2, "0")} /km`}
                </strong>
              </span>
            ))}
          </div>
        )}
      </Card>
      <p className="disclaimer">
        Calculations are estimates based on recent performance. Use them as
        training guidance, not medical advice.
      </p>
    </>
  )
}

function RunCoachBrand({ inverse = false }: { inverse?: boolean }) {
  return (
    <div className={`rc-brand ${inverse ? "inverse" : ""}`}>
      <span className="rc-mark">
        <i />
        <i />
        <i />
      </span>
      <strong>RUNCOACH</strong>
      <small>THAILAND</small>
    </div>
  )
}

function RunnerArt() {
  return (
    <svg
      className="runner-art"
      viewBox="0 0 340 270"
      role="img"
      aria-label="Runner in motion"
    >
      <defs>
        <linearGradient id="runnerBg" x1="0" y1="0" x2="1" y2="1">
          <stop stopColor="#242b3b" />
          <stop offset="1" stopColor="#0b0e14" />
        </linearGradient>
        <linearGradient id="runnerKit" x1="0" y1="0" x2="1" y2="1">
          <stop stopColor="#ff7134" />
          <stop offset="1" stopColor="#fc5200" />
        </linearGradient>
      </defs>
      <rect width="340" height="270" rx="32" fill="url(#runnerBg)" />
      <path
        d="M-20 222C65 175 126 251 218 205c52-26 93-26 142-9"
        fill="none"
        stroke="#fff"
        strokeOpacity=".12"
        strokeWidth="2"
      />
      <path
        d="M0 240c74-35 121 13 190-9 67-22 90-12 164 13"
        fill="none"
        stroke="#fc5200"
        strokeOpacity=".55"
        strokeWidth="5"
        strokeLinecap="round"
      />
      <circle cx="203" cy="62" r="22" fill="#c88060" />
      <path d="M183 58c3-18 31-29 41-4-11-5-22-1-29 8Z" fill="#101318" />
      <path d="m190 88-41 48 37 34 35-58Z" fill="url(#runnerKit)" />
      <path
        d="m157 127-44-12-31 18"
        fill="none"
        stroke="#c88060"
        strokeWidth="15"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="m211 108 35 32 40-12"
        fill="none"
        stroke="#c88060"
        strokeWidth="15"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="m187 164-20 43-51 33"
        fill="none"
        stroke="#d18a68"
        strokeWidth="19"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="m190 163 44 27 24 47"
        fill="none"
        stroke="#b87055"
        strokeWidth="19"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="m116 239-28 4"
        fill="none"
        stroke="#f8fafc"
        strokeWidth="13"
        strokeLinecap="round"
      />
      <path
        d="m258 237 25 8"
        fill="none"
        stroke="#f8fafc"
        strokeWidth="13"
        strokeLinecap="round"
      />
      <path d="m175 151 10 19 25-4 1-24Z" fill="#171b24" />
      <path
        d="M58 68h72M35 91h78M59 114h44"
        stroke="#fff"
        strokeOpacity=".18"
        strokeWidth="7"
        strokeLinecap="round"
      />
    </svg>
  )
}

function RunningLoaderArt() {
  return (
    <svg
      className="runner-loader-art"
      viewBox="0 0 320 240"
      role="img"
      aria-label="Animated runner"
    >
      <g className="speed-lines">
        <path d="M6 63h67" />
        <path d="M6 86h45" />
        <path d="M6 109h58" />
      </g>
      <g className="runner-body">
        <g className="loader-arm back">
          <path d="m132 91-43 9-32 35" />
          <path className="loader-hand" d="m57 135-4 11" />
        </g>
        <g className="loader-leg back">
          <path d="m153 165-39 37-47 15" />
          <path className="loader-sock" d="m68 217-14 3" />
          <path className="loader-shoe" d="m54 220-29 8 31 2" />
          <path className="loader-sole" d="m27 229 29 1" />
        </g>
        <g className="loader-leg front">
          <path d="m174 165 50 18 45 34" />
          <path className="loader-sock" d="m269 217 12 8" />
          <path className="loader-shoe" d="m281 225 23 7-29 3" />
          <path className="loader-sole" d="m277 235 27-3" />
        </g>
        <path
          className="loader-shorts-shadow"
          d="m120 146 51 5 25 17-32 18-51-16Z"
        />
        <path className="loader-shorts" d="m122 137 70 17-19 30-32-4-27-18Z" />
        <path
          className="loader-torso"
          d="m141 76 55 22 25 53-38 23-62-25 6-35-18-7Z"
        />
        <path className="loader-shirt-shadow" d="m126 113 30-10-34 32Z" />
        <path className="loader-shirt-seam" d="m151 107-25 48" />
        <g className="loader-arm front">
          <path d="m201 121 34 34 45-4" />
          <path className="loader-hand" d="m280 151 9-8" />
        </g>
        <path className="loader-neck" d="m171 87 4-22" />
        <path
          className="loader-head"
          d="M150 29c8-16 38-18 54-4 11 10 12 25 9 37l11 12c3 4 1 9-5 10l-8 2c-2 16-12 25-30 24-20-1-33-17-36-36-3-18-2-31 5-45Z"
        />
        <path
          className="loader-hair"
          d="M145 72c-8-20-8-39 4-55l9 10c8-12 24-18 38-18l-5 12c14-3 27 0 38 8l-16 8c4 10 3 20-1 29l-13-9-13 2-3 25-12-14-11 19c-9-5-13-11-15-17Z"
        />
        <path className="loader-ear" d="M162 60c-12-6-14 17 1 20l7-8-7-4" />
        <ellipse className="loader-eye" cx="199" cy="57" rx="3.5" ry="5" />
        <path className="loader-brow" d="m191 46 11-1" />
        <path className="loader-smile" d="M198 78c6 6 12 7 18 4" />
      </g>
      <g className="runner-ground">
        <path d="M-15 220c62-9 92 22 154 13s98-26 194-4" />
        <path d="M-15 228c62-9 92 22 154 13s98-26 194-4" />
      </g>
    </svg>
  )
}

function OnboardingTop({
  step,
  total = 5,
  back,
  dark,
  toggleDark,
}: {
  step?: number
  total?: number
  back?: () => void
  dark: boolean
  toggleDark: () => void
}) {
  return (
    <>
      <div className="onboarding-top">
        {back ? (
          <button className="onboarding-icon" onClick={back}>
            <Icon name="back" />
          </button>
        ) : (
          <RunCoachBrand />
        )}
        {step && (
          <span className="step-label">
            STEP {step} OF {total}
          </span>
        )}
        <button className="onboarding-icon" onClick={toggleDark}>
          <Icon name="moon" />
        </button>
      </div>
      {step && (
        <div className="onboarding-progress">
          <span style={{ width: `${(step / total) * 100}%` }} />
        </div>
      )}
    </>
  )
}

function Onboarding({
  onComplete,
  dark,
  toggleDark,
}: {
  onComplete: () => void
  dark: boolean
  toggleDark: () => void
}) {
  const [stage, setStage] = useState<OnboardingScreen>("splash")
  const [goal, setGoal] = useState("Sub 20 5K")
  const [experience, setExperience] = useState("Intermediate")
  const [connections, setConnections] = useState(["Apple Health"])
  const [plan, setPlan] = useState<"monthly" | "yearly">("yearly")
  const [payment, setPayment] = useState("Apple Pay")
  const [agreed, setAgreed] = useState(true)

  useEffect(() => {
    if (stage !== "splash") return
    const timer = window.setTimeout(() => setStage("welcome"), 2000)
    return () => window.clearTimeout(timer)
  }, [stage])

  const go = (next: OnboardingScreen) => {
    setStage(next)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }
  const previous: Partial<Record<OnboardingScreen, OnboardingScreen>> = {
    goal: "welcome",
    profile: "goal",
    devices: "profile",
    subscription: "devices",
    payment: "subscription",
    register: "payment",
    login: "welcome",
    complete: "register",
  }
  const back = () => go(previous[stage] ?? "welcome")

  if (stage === "splash") {
    return (
      <div className="splash-screen">
        <div className="splash-glow" />
        <RunCoachBrand inverse />
        <RunningLoaderArt />
        <h1>Train Smarter.</h1>
        <h1>Run Faster.</h1>
        <p>AI-powered coaching, built around you.</p>
        <div className="splash-loader">
          <i />
        </div>
      </div>
    )
  }

  if (stage === "welcome") {
    const benefits = [
      "Personalized Training Plans",
      "AI Coaching",
      "Race Prediction",
      "Sleep-Based Recovery",
      "Garmin & Apple Watch Sync",
    ]
    return (
      <div className="onboarding-page welcome-page">
        <OnboardingTop dark={dark} toggleDark={toggleDark} />
        <RunnerArt />
        <div className="welcome-copy">
          <Tag>BUILT FOR EVERY RUNNER</Tag>
          <h1>Your Personal AI Running Coach</h1>
          <p>
            Adaptive training plans powered by sleep, recovery and performance
            analytics.
          </p>
        </div>
        <button
          className="primary onboarding-primary"
          onClick={() => go("goal")}
        >
          Start 14-Day Free Trial <Icon name="arrow" />
        </button>
        <button className="secondary-button" onClick={() => go("register")}>
          Create Account
        </button>
        <button className="tertiary-button" onClick={() => go("login")}>
          Already a member? <strong>Log in</strong>
        </button>
        <div className="welcome-benefits">
          {benefits.map((benefit) => (
            <span key={benefit}>
              <i>
                <Icon name="check" size={12} />
              </i>
              {benefit}
            </span>
          ))}
        </div>
        <div className="social-proof">
          <strong>★★★★★</strong>
          <span>Rated 4.9 by 12,000+ runners</span>
        </div>
        <div className="legal-links">
          <button>Privacy Policy</button>
          <button>Terms</button>
          <button onClick={() => go("login")}>Restore Purchase</button>
        </div>
      </div>
    )
  }

  if (stage === "goal") {
    const goals = [
      ["First 5K", "Complete your first race", "shoe"],
      ["Sub 30 5K", "Build speed and confidence", "clock"],
      ["Sub 25 5K", "Break your next barrier", "bolt"],
      ["Sub 20 5K", "Performance-focused plan", "target"],
      ["10K", "Strength and endurance", "route"],
      ["Half Marathon", "Go further, feel stronger", "route"],
      ["Marathon", "Prepare for 42.2 km", "flame"],
      ["Weight Loss", "Run toward a healthier you", "heart"],
      ["General Fitness", "Build a lasting habit", "spark"],
    ] as const
    return (
      <div className="onboarding-page">
        <OnboardingTop
          step={1}
          back={back}
          dark={dark}
          toggleDark={toggleDark}
        />
        <div className="onboarding-heading">
          <p>LET'S PERSONALIZE YOUR PLAN</p>
          <h1>What's your running goal?</h1>
          <span>Choose the goal that matters most to you.</span>
        </div>
        <div className="goal-grid">
          {goals.map(([title, subtitle, icon]) => (
            <button
              className={goal === title ? "selected" : ""}
              onClick={() => setGoal(title)}
              key={title}
            >
              <span>
                <Icon name={icon} />
              </span>
              <div>
                <strong>{title}</strong>
                <small>{subtitle}</small>
              </div>
              <i>{goal === title && <Icon name="check" size={13} />}</i>
            </button>
          ))}
        </div>
        <div className="sticky-onboarding">
          <button className="primary" onClick={() => go("profile")}>
            Continue <Icon name="arrow" />
          </button>
        </div>
      </div>
    )
  }

  if (stage === "profile") {
    return (
      <div className="onboarding-page">
        <OnboardingTop
          step={2}
          back={back}
          dark={dark}
          toggleDark={toggleDark}
        />
        <div className="onboarding-heading">
          <p>ATHLETE PROFILE</p>
          <h1>Tell us about yourself.</h1>
          <span>We use this to set safe, accurate training targets.</span>
        </div>
        <div className="profile-form">
          <div className="form-two">
            <label>
              AGE
              <div>
                <input defaultValue="29" inputMode="numeric" />
                <span>years</span>
              </div>
            </label>
            <label>
              GENDER
              <select defaultValue="Male">
                <option>Male</option>
                <option>Female</option>
                <option>Non-binary</option>
                <option>Prefer not to say</option>
              </select>
            </label>
          </div>
          <div className="form-two">
            <label>
              WEIGHT
              <div>
                <input defaultValue="68" inputMode="decimal" />
                <span>kg</span>
              </div>
            </label>
            <label>
              HEIGHT
              <div>
                <input defaultValue="178" inputMode="numeric" />
                <span>cm</span>
              </div>
            </label>
          </div>
          <label>
            CURRENT WEEKLY MILEAGE
            <div>
              <input defaultValue="35" inputMode="decimal" />
              <span>km / week</span>
            </div>
          </label>
        </div>
        <div className="experience-section">
          <h3>Running experience</h3>
          <p>How would you describe your current level?</p>
          <div>
            {[
              ["Beginner", "0–1 year"],
              ["Intermediate", "1–3 years"],
              ["Advanced", "3–6 years"],
              ["Elite", "Competitive"],
            ].map(([name, detail]) => (
              <button
                className={experience === name ? "selected" : ""}
                onClick={() => setExperience(name)}
                key={name}
              >
                <i>{experience === name && <Icon name="check" size={12} />}</i>
                <strong>{name}</strong>
                <small>{detail}</small>
              </button>
            ))}
          </div>
        </div>
        <div className="sticky-onboarding">
          <button className="primary" onClick={() => go("devices")}>
            Continue <Icon name="arrow" />
          </button>
        </div>
      </div>
    )
  }

  if (stage === "devices") {
    const devices = [
      ["Apple Health", "Health & recovery data", "♥", "#ef4444"],
      ["Apple Watch", "Workouts & heart rate", "◉", "#111827"],
      ["Garmin", "Training & activity sync", "G", "#1596d1"],
      ["Strava", "Activities & segments", "S", "#fc5200"],
      ["COROS", "Training metrics", "C", "#d71920"],
      ["Polar", "Heart rate & sleep", "P", "#e10026"],
      ["Health Connect", "Android health data", "+", "#2563eb"],
    ]
    const toggle = (name: string) =>
      setConnections((current) =>
        current.includes(name)
          ? current.filter((item) => item !== name)
          : [...current, name],
      )
    return (
      <div className="onboarding-page">
        <OnboardingTop
          step={3}
          back={back}
          dark={dark}
          toggleDark={toggleDark}
        />
        <div className="onboarding-heading">
          <p>SMARTER INSIGHTS</p>
          <h1>Connect your devices.</h1>
          <span>Bring your training, sleep and recovery data together.</span>
        </div>
        <div className="device-list">
          {devices.map(([name, detail, mark, color]) => {
            const connected = connections.includes(name)
            return (
              <Card key={name}>
                <span className="device-logo" style={{ background: color }}>
                  {mark}
                </span>
                <div>
                  <h3>{name}</h3>
                  <p>{connected ? "Connected and syncing" : detail}</p>
                </div>
                <button
                  className={connected ? "connected" : ""}
                  onClick={() => toggle(name)}
                >
                  {connected ? <Icon name="check" size={14} /> : "Connect"}
                </button>
              </Card>
            )
          })}
        </div>
        <div className="privacy-note">
          <Icon name="heart" size={17} />
          <p>
            Your health data stays private and is only used to personalize your
            training.
          </p>
        </div>
        <div className="sticky-onboarding">
          <button className="primary" onClick={() => go("subscription")}>
            Continue <Icon name="arrow" />
          </button>
          <button className="skip-button" onClick={() => go("subscription")}>
            Set up later
          </button>
        </div>
      </div>
    )
  }

  if (stage === "subscription") {
    const features = [
      "Unlimited Training Plans",
      "AI Coach",
      "Sleep Analysis",
      "Race Prediction",
      "Workout Builder",
      "Advanced Analytics",
      "Training Readiness",
      "Priority Support",
    ]
    return (
      <div className="onboarding-page subscription-page">
        <OnboardingTop
          step={4}
          back={back}
          dark={dark}
          toggleDark={toggleDark}
        />
        <div className="premium-orb">
          <Icon name="spark" size={34} />
        </div>
        <div className="onboarding-heading center">
          <p>RUNCOACH PREMIUM</p>
          <h1>Unlock Your Best Performance</h1>
          <span>Start with a 14-Day Free Trial. Cancel anytime.</span>
        </div>
        <div className="pricing-grid">
          <button
            className={plan === "monthly" ? "selected" : ""}
            onClick={() => setPlan("monthly")}
          >
            <i>{plan === "monthly" && <span />}</i>
            <p>MONTHLY</p>
            <h2>฿299</h2>
            <small>per month</small>
          </button>
          <button
            className={
              plan === "yearly" ? "selected recommended" : "recommended"
            }
            onClick={() => setPlan("yearly")}
          >
            <em>RECOMMENDED</em>
            <i>{plan === "yearly" && <span />}</i>
            <p>YEARLY</p>
            <h2>฿1,990</h2>
            <small>per year · ฿166/month</small>
            <strong>SAVE 45%</strong>
          </button>
        </div>
        <div className="premium-features">
          {features.map((feature) => (
            <span key={feature}>
              <i>
                <Icon name="check" size={12} />
              </i>
              {feature}
            </span>
          ))}
        </div>
        <div className="sticky-onboarding">
          <button className="primary" onClick={() => go("payment")}>
            Start Free Trial <Icon name="arrow" />
          </button>
          <p className="trial-copy">
            No charge today · Then{" "}
            {plan === "yearly" ? "฿1,990/year" : "฿299/month"}
          </p>
          <button className="restore-button" onClick={() => go("login")}>
            Already subscribed? <strong>Restore Purchase</strong>
          </button>
        </div>
      </div>
    )
  }

  if (stage === "payment") {
    const payments = [
      ["Apple Pay", "Apple", "#111827"],
      ["Google Pay", "G", "#ffffff"],
      ["Credit / Debit Card", "VISA", "#172554"],
      ["PromptPay", "P", "#143c73"],
      ["TrueMoney Wallet", "T", "#f97316"],
      ["LINE Pay", "LINE", "#06c755"],
    ]
    return (
      <div className="onboarding-page">
        <OnboardingTop
          step={5}
          back={back}
          dark={dark}
          toggleDark={toggleDark}
        />
        <div className="onboarding-heading">
          <p>SECURE CHECKOUT</p>
          <h1>Choose payment method.</h1>
          <span>You won't be charged until your free trial ends.</span>
        </div>
        <div className="payment-methods">
          {payments.map(([name, mark, color]) => (
            <button
              className={payment === name ? "selected" : ""}
              onClick={() => setPayment(name)}
              key={name}
            >
              <span style={{ background: color }}>{mark}</span>
              <strong>{name}</strong>
              <i>{payment === name && <Icon name="check" size={13} />}</i>
            </button>
          ))}
        </div>
        <Card className="payment-summary">
          <div className="summary-title">
            <div className="mini-premium">
              <Icon name="spark" />
            </div>
            <span>
              <strong>RunCoach Premium</strong>
              <small>
                {plan === "yearly" ? "Yearly plan" : "Monthly plan"}
              </small>
            </span>
          </div>
          <div>
            <span>14-Day Free Trial</span>
            <strong>฿0 today</strong>
          </div>
          <div>
            <span>Starting 26 August 2025</span>
            <strong>
              {plan === "yearly" ? "฿1,990 / year" : "฿299 / month"}
            </strong>
          </div>
        </Card>
        <div className="secure-note">
          <Icon name="check" size={15} /> Secure and encrypted checkout
        </div>
        <div className="sticky-onboarding">
          <button className="primary" onClick={() => go("register")}>
            Complete Purchase <Icon name="arrow" />
          </button>
          <p className="trial-copy">
            By continuing, you agree to the subscription terms.
          </p>
        </div>
      </div>
    )
  }

  if (stage === "register" || stage === "login") {
    const registering = stage === "register"
    return (
      <div className="onboarding-page auth-page">
        <OnboardingTop back={back} dark={dark} toggleDark={toggleDark} />
        <div className="onboarding-heading center">
          <p>{registering ? "JOIN RUNCOACH" : "WELCOME BACK"}</p>
          <h1>
            {registering ? "Create your account." : "Log in to RunCoach."}
          </h1>
          <span>
            {registering
              ? "Save your plan and sync across all your devices."
              : "Your next run is waiting."}
          </span>
        </div>
        <div className="social-auth">
          {[
            ["Apple", "●"],
            ["Google", "G"],
            ["LINE", "LINE"],
            ...(registering ? [["Facebook", "f"]] : []),
          ].map(([name, mark]) => (
            <button key={name}>
              <span className={`social-mark ${name.toLowerCase()}`}>
                {mark}
              </span>
              Continue with {name}
            </button>
          ))}
        </div>
        <div className="auth-divider">
          <span>or continue with email</span>
        </div>
        <div className="auth-form">
          <label>
            EMAIL
            <input type="email" placeholder="you@example.com" />
          </label>
          <label>
            PASSWORD
            <input type="password" placeholder="At least 8 characters" />
          </label>
          {registering && (
            <label>
              CONFIRM PASSWORD
              <input type="password" placeholder="Repeat your password" />
            </label>
          )}
        </div>
        <div className="auth-options">
          <label>
            <button
              className={agreed ? "checked" : ""}
              onClick={() => setAgreed(!agreed)}
            >
              {agreed && <Icon name="check" size={11} />}
            </button>
            {registering
              ? "I agree to the Terms & Privacy Policy"
              : "Remember me"}
          </label>
          {!registering && <button>Forgot password?</button>}
        </div>
        <button
          className="primary"
          disabled={registering && !agreed}
          onClick={() => (registering ? go("complete") : onComplete())}
        >
          {registering ? "Create Account" : "Log In"} <Icon name="arrow" />
        </button>
        <button
          className="switch-auth"
          onClick={() => go(registering ? "login" : "register")}
        >
          {registering ? "Already have an account? " : "New to RunCoach? "}
          <strong>{registering ? "Log in" : "Create account"}</strong>
        </button>
      </div>
    )
  }

  if (stage === "complete") {
    return (
      <div className="onboarding-page complete-page">
        <RunCoachBrand />
        <div className="success-animation">
          <span>
            <Icon name="check" size={32} />
          </span>
          <i />
          <i />
          <i />
        </div>
        <div className="ai-coach-avatar">
          <Icon name="spark" size={34} />
        </div>
        <Tag tone="blue">AI COACH IS READY</Tag>
        <h1>Your training plan is ready.</h1>
        <p>
          Built around your goals, fitness and schedule. We'll adapt it as you
          progress.
        </p>
        <Card className="ready-plan">
          <div>
            <span>YOUR GOAL</span>
            <strong>{goal}</strong>
          </div>
          <div>
            <span>TARGET DATE</span>
            <strong>120 Days</strong>
          </div>
          <div className="finish-time">
            <span>PROJECTED FINISH</span>
            <strong>19:52</strong>
            <Tag tone="green">ON TRACK</Tag>
          </div>
        </Card>
        <button className="primary" onClick={onComplete}>
          Go To Dashboard <Icon name="arrow" />
        </button>
        <p className="coach-signoff">
          Your coach will check in after every run.
        </p>
      </div>
    )
  }

  return null
}

export default function App() {
  const [onboarding, setOnboarding] = useState(true)
  const [screen, setScreen] = useState<Screen>("home")
  const [dark, setDark] = useState(false)
  const primary = useMemo(
    () =>
      nav.find((n) => n.id === screen)?.id ??
      (screen === "coach"
        ? "coach"
        : screen === "profile" || screen === "settings"
          ? "profile"
          : screen === "training" ||
              screen === "workout" ||
              screen === "builder"
            ? "training"
            : "analytics"),
    [screen],
  )
  if (onboarding) {
    return (
      <div className={dark ? "app dark onboarding-app" : "app onboarding-app"}>
        <Onboarding
          dark={dark}
          toggleDark={() => setDark(!dark)}
          onComplete={() => setOnboarding(false)}
        />
      </div>
    )
  }
  const go = (s: Screen) => {
    setScreen(s)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }
  const content = {
    home: <Home go={go} />,
    training: <Training go={go} />,
    workout: <Workout go={go} />,
    builder: <Builder go={go} />,
    analytics: <Analytics go={go} />,
    predictor: <Predictor go={go} />,
    records: <Records go={go} />,
    coach: <Coach />,
    profile: <Profile go={go} dark={dark} toggleDark={() => setDark(!dark)} />,
    settings: (
      <Settings go={go} dark={dark} toggleDark={() => setDark(!dark)} />
    ),
    calculators: <Calculators go={go} />,
  }[screen]
  return (
    <div className={dark ? "app dark" : "app"}>
      <aside className="desktop-nav">
        <button className="logo" onClick={() => go("home")}>
          <span>R</span>RUNCOACH
        </button>
        <nav>
          {nav.map((n) => (
            <button
              className={primary === n.id ? "active" : ""}
              onClick={() => go(n.id)}
              key={n.id}
            >
              <Icon name={n.icon} />
              <span>{n.label}</span>
            </button>
          ))}
        </nav>
        <Card className="nav-goal">
          <Tag>RACE GOAL</Tag>
          <strong>Sub 20:00</strong>
          <p>City Park 5K</p>
          <ProgressBar value={74} />
        </Card>
        <button className="nav-settings" onClick={() => go("settings")}>
          <Icon name="settings" />
          Settings
        </button>
      </aside>
      <main className="app-content">
        {content}
        <footer>
          <span className="footer-logo">RUNCOACH THAILAND</span>
          <p>Built for the run ahead.</p>
        </footer>
      </main>
      <nav className="bottom-nav">
        {nav.map((n) => (
          <button
            className={primary === n.id ? "active" : ""}
            onClick={() => go(n.id)}
            key={n.id}
          >
            <Icon name={n.icon} />
            <span>{n.label}</span>
          </button>
        ))}
      </nav>
    </div>
  )
}
